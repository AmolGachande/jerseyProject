package jersey.project.student;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StudentDao {

	List<Student> student;
	public StudentDao()
	{
		student=new ArrayList<>();
		Student s=new Student(1,"amol","12-12-2003","12-12-2020");
		Student s1=new Student(2,"ram","12-12-2003","12-12-2020");
		Student s2=new Student(3,"ravi","12-12-2003","12-12-2020");
		student.addAll(Arrays.asList(s,s1,s2));
	}
	
	public List<Student> getAllStudent()
	{
		return student;
	}

	public void createStudent(Student stud) 
	{
		student.add(stud);
	}
	
	public Student getStudentByRollnumber(int rollnumber)
	{
		return student.stream().filter(x->x.getRollnumber()==rollnumber)
		.collect(Collectors.toList()).get(0);
	}
	
	public List<Student> removeStudent(int rollnumber)
	{
		student.removeIf(x->x.getRollnumber()==rollnumber);
		return student;
	}
	
	public List<Student> updateStudent(int rollnumber,String name)
	{
		 student.stream().filter(x->x.getRollnumber()==rollnumber)
		.collect(Collectors.toList()).get(0).setName(name);
		 return student;
	}
}
